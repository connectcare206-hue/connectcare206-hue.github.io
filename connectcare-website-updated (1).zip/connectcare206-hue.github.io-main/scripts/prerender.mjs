import fs from 'fs';
const site = 'https://connectcare.co.in';
const pages = JSON.parse(fs.readFileSync('seoPages.json', 'utf8'));
const tpl = fs.readFileSync('dist/index.html', 'utf8');
const esc = s => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/"/g, '&quot;');
for (const p of pages) {
  const url = `${site}/${p.slug}`;
  const ld = [
    { '@context': 'https://schema.org', '@type': 'Service', name: p.name, description: p.description, url, provider: { '@type': 'EmploymentAgency', name: 'ConnectCare Services', url: site } },
    { '@context': 'https://schema.org', '@type': 'FAQPage', mainEntity: p.faqs.map(f => ({ '@type': 'Question', name: f.q, acceptedAnswer: { '@type': 'Answer', text: f.a } })) },
    { '@context': 'https://schema.org', '@type': 'BreadcrumbList', itemListElement: [{ '@type': 'ListItem', position: 1, name: 'Home', item: site + '/' }, { '@type': 'ListItem', position: 2, name: p.name, item: url }] }
  ].map(o => `<script type="application/ld+json">${JSON.stringify(o)}</script>`).join('\n');
  const body = `<h1>${esc(p.h1)}</h1><p>${esc(p.intro)}</p>` +
    p.sections.map(s => `<h2>${esc(s.h)}</h2>` + (s.p ? `<p>${esc(s.p)}</p>` : '') + (s.list ? `<ul>${s.list.map(i => `<li>${esc(i)}</li>`).join('')}</ul>` : '')).join('') +
    `<h2>Frequently Asked Questions</h2>` + p.faqs.map(f => `<h3>${esc(f.q)}</h3><p>${esc(f.a)}</p>`).join('');
  let h = tpl
    .replace(/<title>.*?<\/title>/, `<title>${esc(p.title)}</title>`)
    .replace(/(<meta name="description" content=")[^"]*"/, `$1${esc(p.description)}"`)
    .replace(/(<link rel="canonical" href=")[^"]*"/, `$1${url}"`)
    .replace(/(<meta property="og:url" content=")[^"]*"/, `$1${url}"`)
    .replace(/(<meta property="og:title" content=")[^"]*"/, `$1${esc(p.title)}"`)
    .replace(/(<meta name="twitter:title" content=")[^"]*"/, `$1${esc(p.title)}"`)
    .replace('</head>', `${ld}\n</head>`)
    .replace('<div id="root"></div>', `<div id="root">${body}</div>`);
  fs.mkdirSync(`dist/${p.slug}`, { recursive: true });
  fs.writeFileSync(`dist/${p.slug}/index.html`, h);
}
const urls = ['/', ...pages.map(p => '/' + p.slug)];
fs.writeFileSync('dist/sitemap.xml', `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls.map(u => `  <url><loc>${site}${u}</loc></url>`).join('\n')}\n</urlset>\n`);
console.log('prerendered', pages.length, 'pages');
